# GlobalTinyy

Global Investment Yapı Geliştirme A.Ş. için sıfırdan hazırlanmış, 17 sayfalık, bağımlılıksız statik site.

## Geliştirme
```bash
npm run dev
```

## Build
```bash
npm run build
```

`dist/` klasörü GitHub Pages için hazırdır.

## GitHub Pages
Repo Settings → Pages → Source: **GitHub Actions** seçin. `main` veya `master` branch'e push sonrası workflow otomatik yayınlar.

## SEO
- Her sayfada özel title ve meta description
- Canonical URL
- Open Graph etiketleri
- JSON-LD WebPage verisi
- sitemap.xml
- robots.txt

## Renk paleti
`#ADFCF9` · `#89A894` · `#4B644A` · `#49393B` · `#341C1C`
